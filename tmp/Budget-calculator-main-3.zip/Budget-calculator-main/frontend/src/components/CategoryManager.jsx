import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import * as LucideIcons from 'lucide-react';
import { toast } from 'sonner';

const CategoryManager = ({ categories, onCategoryUpdate }) => {
  const [editingCategory, setEditingCategory] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [showAddForm, setShowAddForm] = useState(false);
  const [newCategory, setNewCategory] = useState({
    name: '',
    nameit: '',
    estimatedCost: '',
    actualCost: 0,
    color: '#6B7280',
    icon: 'Package'
  });

  const handleEdit = (category) => {
    setEditingCategory(category.id);
    setEditForm({
      name: category.name,
      estimatedCost: category.estimatedCost,
      actualCost: category.actualCost
    });
  };

  const handleSave = (categoryId) => {
    const updatedCategory = {
      ...categories.find(c => c.id === categoryId),
      ...editForm,
      percentage: Math.round((editForm.estimatedCost / 24000) * 100) // Assuming total budget of 24000
    };
    
    onCategoryUpdate(updatedCategory);
    setEditingCategory(null);
    setEditForm({});
  };

  const handleCancel = () => {
    setEditingCategory(null);
    setEditForm({});
  };

  const handleAddCategory = () => {
    if (!newCategory.name || !newCategory.estimatedCost) {
      toast.error("Compila tutti i campi obbligatori");
      return;
    }

    const category = {
      ...newCategory,
      id: Date.now(), // Simple ID generation
      estimatedCost: parseFloat(newCategory.estimatedCost),
      percentage: Math.round((parseFloat(newCategory.estimatedCost) / 24000) * 100),
      subcategories: []
    };

    onCategoryUpdate(category);
    setNewCategory({
      name: '',
      nameit: '',
      estimatedCost: '',
      actualCost: 0,
      color: '#6B7280',
      icon: 'Package'
    });
    setShowAddForm(false);
    toast.success("Nuova categoria aggiunta con successo!");
  };

  const colorOptions = [
    '#E91E63', '#FF9800', '#9C27B0', '#2196F3', '#4CAF50', 
    '#FF5722', '#607D8B', '#795548', '#F44336', '#00BCD4'
  ];

  const iconOptions = [
    'Package', 'MapPin', 'UtensilsCrossed', 'Camera', 'Shirt', 
    'Music', 'Flower', 'Car', 'Gift', 'Heart', 'Star', 'Crown'
  ];

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR'
    }).format(amount);
  };

  const getProgressColor = (actual, estimated) => {
    const percentage = (actual / estimated) * 100;
    if (percentage <= 80) return 'bg-green-500';
    if (percentage <= 100) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getStatusBadge = (actual, estimated) => {
    const percentage = (actual / estimated) * 100;
    if (percentage === 0) return <Badge variant="secondary">Non iniziato</Badge>;
    if (percentage <= 50) return <Badge variant="default" className="bg-blue-500">In corso</Badge>;
    if (percentage <= 100) return <Badge variant="default" className="bg-yellow-500">Quasi completato</Badge>;
    return <Badge variant="destructive">Budget superato</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gestione Categorie</h2>
          <p className="text-gray-600">Modifica i budget e traccia le spese per ogni categoria</p>
        </div>
        <Button 
          className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
          onClick={() => setShowAddForm(true)}
        >
          <LucideIcons.Plus className="w-4 h-4 mr-2" />
          Aggiungi Categoria
        </Button>
      </div>

      {/* Add Category Form */}
      {showAddForm && (
        <Card className="border-2 border-pink-200">
          <CardHeader>
            <CardTitle className="text-pink-700">Aggiungi Nuova Categoria</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="new-category-name">Nome Categoria *</Label>
                <Input
                  id="new-category-name"
                  value={newCategory.name}
                  onChange={(e) => setNewCategory(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="es. Decorazioni Floreali"
                />
              </div>
              <div>
                <Label htmlFor="new-category-short">Nome Breve *</Label>
                <Input
                  id="new-category-short"
                  value={newCategory.nameit}
                  onChange={(e) => setNewCategory(prev => ({ ...prev, nameit: e.target.value }))}
                  placeholder="es. Fiori"
                />
              </div>
              <div>
                <Label htmlFor="new-category-cost">Budget Stimato *</Label>
                <div className="relative">
                  <LucideIcons.Euro className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    id="new-category-cost"
                    type="number"
                    value={newCategory.estimatedCost}
                    onChange={(e) => setNewCategory(prev => ({ ...prev, estimatedCost: e.target.value }))}
                    placeholder="0"
                    className="pl-10"
                  />
                </div>
              </div>
              <div>
                <Label>Icona</Label>
                <div className="grid grid-cols-6 gap-2">
                  {iconOptions.map((icon) => {
                    const IconComponent = LucideIcons[icon];
                    return (
                      <button
                        key={icon}
                        type="button"
                        onClick={() => setNewCategory(prev => ({ ...prev, icon }))}
                        className={`p-2 rounded border-2 transition-all ${
                          newCategory.icon === icon 
                            ? 'border-pink-500 bg-pink-50' 
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <IconComponent className="w-4 h-4 mx-auto" />
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
            <div>
              <Label>Colore</Label>
              <div className="flex gap-2 flex-wrap">
                {colorOptions.map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setNewCategory(prev => ({ ...prev, color }))}
                    className={`w-8 h-8 rounded-full border-2 transition-all ${
                      newCategory.color === color 
                        ? 'border-gray-800 scale-110' 
                        : 'border-gray-300 hover:scale-105'
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>
            <div className="flex gap-2 pt-4">
              <Button 
                onClick={handleAddCategory} 
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                <LucideIcons.Plus className="w-4 h-4 mr-2" />
                Aggiungi Categoria
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setShowAddForm(false)}
                className="flex-1"
              >
                <LucideIcons.X className="w-4 h-4 mr-2" />
                Annulla
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {categories.map((category) => {
          const IconComponent = LucideIcons[category.icon] || LucideIcons.Package;
          const isEditing = editingCategory === category.id;
          const progressPercentage = (category.actualCost / category.estimatedCost) * 100;

          return (
            <Card key={category.id} className="shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div 
                      className="p-2 rounded-full"
                      style={{ backgroundColor: `${category.color}20` }}
                    >
                      <IconComponent 
                        className="w-5 h-5" 
                        style={{ color: category.color }}
                      />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{category.nameit}</CardTitle>
                      <p className="text-sm text-gray-600">{category.percentage}% del budget totale</p>
                    </div>
                  </div>
                  {getStatusBadge(category.actualCost, category.estimatedCost)}
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {isEditing ? (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor={`name-${category.id}`}>Nome Categoria</Label>
                      <Input
                        id={`name-${category.id}`}
                        value={editForm.name}
                        onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor={`estimated-${category.id}`}>Budget Stimato</Label>
                      <Input
                        id={`estimated-${category.id}`}
                        type="number"
                        value={editForm.estimatedCost}
                        onChange={(e) => setEditForm(prev => ({ ...prev, estimatedCost: Number(e.target.value) }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor={`actual-${category.id}`}>Spesa Effettiva</Label>
                      <Input
                        id={`actual-${category.id}`}
                        type="number"
                        value={editForm.actualCost}
                        onChange={(e) => setEditForm(prev => ({ ...prev, actualCost: Number(e.target.value) }))}
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        onClick={() => handleSave(category.id)}
                        className="flex-1 bg-green-600 hover:bg-green-700"
                      >
                        <LucideIcons.Check className="w-4 h-4 mr-2" />
                        Salva
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={handleCancel}
                        className="flex-1"
                      >
                        <LucideIcons.X className="w-4 h-4 mr-2" />
                        Annulla
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    {/* Budget Progress */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Progresso spesa</span>
                        <span className="font-medium">
                          {formatCurrency(category.actualCost)} / {formatCurrency(category.estimatedCost)}
                        </span>
                      </div>
                      <Progress 
                        value={Math.min(progressPercentage, 100)} 
                        className="h-3"
                      />
                      <div className="flex justify-between text-xs text-gray-500">
                        <span>{Math.round(progressPercentage)}% utilizzato</span>
                        <span>
                          {category.actualCost < category.estimatedCost 
                            ? `Rimanente: ${formatCurrency(category.estimatedCost - category.actualCost)}`
                            : `Superato: ${formatCurrency(category.actualCost - category.estimatedCost)}`
                          }
                        </span>
                      </div>
                    </div>

                    {/* Subcategories */}
                    {category.subcategories && category.subcategories.length > 0 && (
                      <div className="border-t pt-4">
                        <h4 className="font-medium text-gray-900 mb-2">Dettaglio spese</h4>
                        <div className="space-y-2">
                          {category.subcategories.map((sub, index) => (
                            <div key={index} className="flex justify-between text-sm">
                              <span className="text-gray-600">{sub.name}</span>
                              <span className="font-medium">{formatCurrency(sub.cost)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex gap-2 pt-4 border-t">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleEdit(category)}
                        className="flex-1"
                      >
                        <LucideIcons.Edit3 className="w-4 h-4 mr-2" />
                        Modifica
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="flex-1"
                      >
                        <LucideIcons.Plus className="w-4 h-4 mr-2" />
                        Aggiungi Spesa
                      </Button>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default CategoryManager;