import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Calculator, 
  PieChart, 
  Euro, 
  TrendingUp,
  Calendar,
  Users,
  Edit3,
  Save,
  X
} from 'lucide-react';
import { mockStats } from '../mockData';

const BudgetOverview = ({ onBudgetChange }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [tempBudget, setTempBudget] = useState(mockStats.totalBudget);
  const [stats, setStats] = useState(mockStats);

  const handleSaveBudget = () => {
    const updatedStats = { ...stats, totalBudget: tempBudget };
    setStats(updatedStats);
    onBudgetChange && onBudgetChange(tempBudget);
    setIsEditing(false);
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR'
    }).format(amount);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {/* Total Budget Card */}
      <Card className="border-l-4 border-l-pink-500 shadow-lg hover:shadow-xl transition-all duration-300">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-gray-600 flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Calculator className="w-4 h-4" />
              Budget Totale
            </span>
            {!isEditing ? (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsEditing(true)}
                className="h-6 w-6 p-0"
              >
                <Edit3 className="w-3 h-3" />
              </Button>
            ) : (
              <div className="flex gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleSaveBudget}
                  className="h-6 w-6 p-0 text-green-600"
                >
                  <Save className="w-3 h-3" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setIsEditing(false);
                    setTempBudget(stats.totalBudget);
                  }}
                  className="h-6 w-6 p-0 text-red-600"
                >
                  <X className="w-3 h-3" />
                </Button>
              </div>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isEditing ? (
            <div className="flex items-center gap-2">
              <Euro className="w-4 h-4 text-gray-500" />
              <Input
                type="number"
                value={tempBudget}
                onChange={(e) => setTempBudget(Number(e.target.value))}
                className="text-2xl font-bold border-0 p-0 h-auto focus-visible:ring-0"
              />
            </div>
          ) : (
            <div className="text-3xl font-bold text-gray-900 flex items-center gap-1">
              {formatCurrency(stats.totalBudget)}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Amount Spent Card */}
      <Card className="border-l-4 border-l-orange-500 shadow-lg hover:shadow-xl transition-all duration-300">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
            <Euro className="w-4 h-4" />
            Speso Finora
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-gray-900">
            {formatCurrency(stats.totalSpent)}
          </div>
          <div className="mt-2">
            <Progress value={stats.percentageSpent} className="h-2" />
            <p className="text-xs text-gray-600 mt-1">{stats.percentageSpent}% del budget</p>
          </div>
        </CardContent>
      </Card>

      {/* Remaining Budget Card */}
      <Card className="border-l-4 border-l-green-500 shadow-lg hover:shadow-xl transition-all duration-300">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Budget Rimanente
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-green-600">
            {formatCurrency(stats.remainingBudget)}
          </div>
          <Badge 
            variant={stats.remainingBudget > 0 ? "default" : "destructive"}
            className="mt-2"
          >
            {stats.remainingBudget > 0 ? "Nei limiti" : "Budget superato"}
          </Badge>
        </CardContent>
      </Card>

      {/* Days to Wedding Card */}
      <Card className="border-l-4 border-l-purple-500 shadow-lg hover:shadow-xl transition-all duration-300">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Giorni al Matrimonio
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-purple-600">
            {stats.daysToWedding}
          </div>
          <p className="text-xs text-gray-600 mt-1 flex items-center gap-1">
            <Users className="w-3 h-3" />
            {stats.vendorsPaid}/{stats.vendorsTotal} fornitori pagati
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default BudgetOverview;