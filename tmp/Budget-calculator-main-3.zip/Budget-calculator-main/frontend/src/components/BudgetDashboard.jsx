import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import BudgetOverview from './BudgetOverview';
import BudgetChart from './BudgetChart';
import BudgetCalculator from './BudgetCalculator';
import CategoryManager from './CategoryManager';
import VendorManager from './VendorManager';
import UpcomingPayments from './UpcomingPayments';
import { 
  Heart, 
  Calculator, 
  PieChart, 
  Users, 
  Calendar,
  CreditCard,
  Settings,
  Download,
  Bell,
  Plus
} from 'lucide-react';
import { mockBudgetCategories, mockStats, mockUpcomingPayments } from '../mockData';
import { toast } from 'sonner';

const BudgetDashboard = () => {
  const [categories, setCategories] = useState(mockBudgetCategories);
  const [activeTab, setActiveTab] = useState('overview');
  const [showCalculator, setShowCalculator] = useState(false);

  const handleBudgetCalculation = (calculatedBudget) => {
    toast.success("Budget calcolato con successo!", {
      description: `Budget totale: €${calculatedBudget.totalBudget.toLocaleString()}`
    });
    setShowCalculator(false);
    setActiveTab('overview');
  };

  const handleBudgetChange = (newBudget) => {
    toast.success("Budget aggiornato!", {
      description: `Nuovo budget: €${newBudget.toLocaleString()}`
    });
  };

  const handleCategoryUpdate = (updatedCategory) => {
    setCategories(prev => {
      const existingIndex = prev.findIndex(cat => cat.id === updatedCategory.id);
      if (existingIndex >= 0) {
        // Update existing category
        return prev.map(cat => 
          cat.id === updatedCategory.id ? updatedCategory : cat
        );
      } else {
        // Add new category
        return [...prev, updatedCategory];
      }
    });
    
    const isNewCategory = !categories.find(cat => cat.id === updatedCategory.id);
    if (isNewCategory) {
      toast.success("Nuova categoria aggiunta con successo!");
    } else {
      toast.success("Categoria aggiornata con successo!");
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR'
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Heart className="w-8 h-8 text-pink-500" />
                <h1 className="text-2xl font-bold text-gray-900">Matrimonio.com</h1>
              </div>
              <Badge variant="secondary" className="bg-pink-100 text-pink-800">
                Budgeter
              </Badge>
            </div>
            <div className="flex items-center space-x-3">
              <Button 
                variant="outline" 
                size="sm"
                className="hidden md:flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                Scarica PDF
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                className="hidden md:flex items-center gap-2"
              >
                <Bell className="w-4 h-4" />
                Promemoria
              </Button>
              <Button 
                onClick={() => setShowCalculator(true)}
                className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white"
                size="sm"
              >
                <Calculator className="w-4 h-4 mr-2" />
                Calcola Budget
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-pink-500 to-purple-600 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-4xl font-bold mb-4">
              Tieni sotto controllo le spese del matrimonio
            </h2>
            <p className="text-xl text-pink-100 max-w-3xl mx-auto">
              Non dovrai più preoccuparti di sforare il budget. Controlla le spese, 
              programma i pagamenti e tieni aggiornata la lista dei fornitori da pagare
            </p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Calculator Modal */}
        {showCalculator && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center p-4 border-b">
                <h3 className="text-lg font-semibold">Calcola il tuo budget</h3>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setShowCalculator(false)}
                >
                  ×
                </Button>
              </div>
              <div className="p-4">
                <BudgetCalculator onCalculate={handleBudgetCalculation} />
              </div>
            </div>
          </div>
        )}

        {/* Budget Overview Cards */}
        <BudgetOverview onBudgetChange={handleBudgetChange} />

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <PieChart className="w-4 h-4" />
              <span className="hidden sm:inline">Panoramica</span>
            </TabsTrigger>
            <TabsTrigger value="categories" className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              <span className="hidden sm:inline">Categorie</span>
            </TabsTrigger>
            <TabsTrigger value="vendors" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span className="hidden sm:inline">Fornitori</span>
            </TabsTrigger>
            <TabsTrigger value="payments" className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              <span className="hidden sm:inline">Pagamenti</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span className="hidden sm:inline">Analisi</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <BudgetChart categories={categories} />
            
            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-blue-800">Categoria più costosa</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-900">Location</div>
                  <p className="text-blue-700">{formatCurrency(8500)} stimati</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-green-800">Prossimo pagamento</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-900">20 Mag</div>
                  <p className="text-green-700">Catering - {formatCurrency(5800)}</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-purple-800">Risparmio potenziale</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-900">{formatCurrency(1360)}</div>
                  <p className="text-purple-700">Budget rimanente</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="categories">
            <CategoryManager 
              categories={categories} 
              onCategoryUpdate={handleCategoryUpdate}
            />
          </TabsContent>

          <TabsContent value="vendors">
            <VendorManager categories={categories} />
          </TabsContent>

          <TabsContent value="payments">
            <UpcomingPayments payments={mockUpcomingPayments} />
          </TabsContent>

          <TabsContent value="analytics">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Progressi nel tempo</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">Analisi dei tuoi progressi di spesa nel tempo</p>
                  <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
                    <p className="text-gray-500">Grafico temporale (implementazione futura)</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Confronto con altri matrimoni</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">Come si confronta il tuo budget con matrimoni simili</p>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>Budget medio per matrimonio simile</span>
                      <span className="font-semibold">{formatCurrency(26500)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Il tuo budget</span>
                      <span className="font-semibold text-green-600">{formatCurrency(24000)}</span>
                    </div>
                    <div className="flex justify-between text-green-600">
                      <span>Risparmio rispetto alla media</span>
                      <span className="font-semibold">{formatCurrency(2500)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="bg-gray-50 border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600">
            <p>© 2024 Matrimonio.com - Il budgeter più completo per il tuo matrimonio perfetto</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default BudgetDashboard;