import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Calculator, MapPin, Users, Heart, Sparkles } from 'lucide-react';

const BudgetCalculator = ({ onCalculate }) => {
  const [formData, setFormData] = useState({
    totalBudget: '',
    guestCount: '',
    weddingStyle: '',
    location: ''
  });

  const weddingStyles = [
    { value: 'elegante', label: 'Elegante e Formale', multiplier: 1.2 },
    { value: 'rustico', label: 'Rustico e Country', multiplier: 0.9 },
    { value: 'moderno', label: 'Moderno e Minimalista', multiplier: 1.0 },
    { value: 'vintage', label: 'Vintage e Romantico', multiplier: 1.1 },
    { value: 'boho', label: 'Bohemian e Naturale', multiplier: 0.95 }
  ];

  const locations = [
    { value: 'nord', label: 'Nord Italia', multiplier: 1.15 },
    { value: 'centro', label: 'Centro Italia', multiplier: 1.0 },
    { value: 'sud', label: 'Sud Italia', multiplier: 0.85 },
    { value: 'isole', label: 'Isole', multiplier: 0.8 }
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const calculateBudget = () => {
    if (!formData.totalBudget || !formData.guestCount || !formData.weddingStyle || !formData.location) {
      return;
    }

    const baseAmount = parseFloat(formData.totalBudget);
    const styleMultiplier = weddingStyles.find(s => s.value === formData.weddingStyle)?.multiplier || 1;
    const locationMultiplier = locations.find(l => l.value === formData.location)?.multiplier || 1;
    
    // Base category percentages
    const basePercentages = {
      location: 35,
      catering: 25,
      photography: 15,
      attire: 10,
      music: 7,
      flowers: 5,
      transport: 2,
      misc: 1
    };

    // Adjust percentages based on style and location
    const adjustedBudget = {
      totalBudget: baseAmount,
      guestCount: parseInt(formData.guestCount),
      weddingStyle: formData.weddingStyle,
      location: formData.location,
      categories: Object.entries(basePercentages).map(([key, percentage]) => {
        const adjustedAmount = (baseAmount * percentage / 100) * styleMultiplier * locationMultiplier;
        return {
          category: key,
          percentage,
          amount: Math.round(adjustedAmount)
        };
      })
    };

    onCalculate && onCalculate(adjustedBudget);
  };

  const isFormValid = formData.totalBudget && formData.guestCount && formData.weddingStyle && formData.location;

  return (
    <Card className="shadow-lg hover:shadow-xl transition-all duration-300 border-l-4 border-l-pink-500">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="w-5 h-5 text-pink-500" />
          Calcolatore Budget Matrimonio
        </CardTitle>
        <p className="text-sm text-gray-600">
          Rispondi a 4 semplici domande per ottenere una stima personalizzata del tuo budget
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Total Budget */}
        <div className="space-y-2">
          <Label htmlFor="totalBudget" className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-pink-500" />
            Quale è il tuo budget totale?
          </Label>
          <div className="relative">
            <Input
              id="totalBudget"
              type="number"
              placeholder="es. 25000"
              value={formData.totalBudget}
              onChange={(e) => handleInputChange('totalBudget', e.target.value)}
              className="pl-8"
            />
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">€</span>
          </div>
        </div>

        {/* Guest Count */}
        <div className="space-y-2">
          <Label htmlFor="guestCount" className="flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-500" />
            Quanti invitati avrete?
          </Label>
          <Input
            id="guestCount"
            type="number"
            placeholder="es. 100"
            value={formData.guestCount}
            onChange={(e) => handleInputChange('guestCount', e.target.value)}
          />
        </div>

        {/* Wedding Style */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2">
            <Heart className="w-4 h-4 text-purple-500" />
            Che stile di matrimonio desiderate?
          </Label>
          <Select value={formData.weddingStyle} onValueChange={(value) => handleInputChange('weddingStyle', value)}>
            <SelectTrigger>
              <SelectValue placeholder="Seleziona lo stile del matrimonio" />
            </SelectTrigger>
            <SelectContent>
              {weddingStyles.map((style) => (
                <SelectItem key={style.value} value={style.value}>
                  {style.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Location */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-green-500" />
            In che zona d'Italia si svolgerà il matrimonio?
          </Label>
          <Select value={formData.location} onValueChange={(value) => handleInputChange('location', value)}>
            <SelectTrigger>
              <SelectValue placeholder="Seleziona la zona" />
            </SelectTrigger>
            <SelectContent>
              {locations.map((location) => (
                <SelectItem key={location.value} value={location.value}>
                  {location.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Calculate Button */}
        <Button 
          onClick={calculateBudget}
          disabled={!isFormValid}
          className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-semibold py-3 rounded-lg transition-all duration-300 transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
        >
          <Calculator className="w-4 h-4 mr-2" />
          Calcola il Budget Personalizzato
        </Button>
      </CardContent>
    </Card>
  );
};

export default BudgetCalculator;