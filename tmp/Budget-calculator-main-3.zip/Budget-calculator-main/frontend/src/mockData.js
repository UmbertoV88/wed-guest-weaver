// Mock data for Matrimonio.com Budget Tool

export const mockBudgetCategories = [
  {
    id: 1,
    name: "Location/Venue",
    nameit: "Location",
    icon: "MapPin",
    estimatedCost: 8500,
    actualCost: 8000,
    percentage: 35,
    color: "#E91E63",
    subcategories: [
      { name: "Affitto sala", cost: 6000 },
      { name: "Decorazioni location", cost: 2000 }
    ]
  },
  {
    id: 2,
    name: "Catering",
    nameit: "Catering",
    icon: "UtensilsCrossed",
    estimatedCost: 6000,
    actualCost: 5800,
    percentage: 25,
    color: "#FF9800",
    subcategories: [
      { name: "Menu principale", cost: 4500 },
      { name: "Aperitivo", cost: 1300 }
    ]
  },
  {
    id: 3,
    name: "Fotografia e Video",
    nameit: "Foto/Video",
    icon: "Camera",
    estimatedCost: 3600,
    actualCost: 3200,
    percentage: 15,
    color: "#9C27B0",
    subcategories: [
      { name: "Fotografo", cost: 2200 },
      { name: "Videografo", cost: 1000 }
    ]
  },
  {
    id: 4,
    name: "Abiti e Beauty",
    nameit: "Abbigliamento",
    icon: "Shirt",
    estimatedCost: 2400,
    actualCost: 2100,
    percentage: 10,
    color: "#2196F3",
    subcategories: [
      { name: "Abito sposa", cost: 1200 },
      { name: "Abito sposo", cost: 600 },
      { name: "Trucco e parrucchiere", cost: 300 }
    ]
  },
  {
    id: 5,
    name: "Musica e Intrattenimento",
    nameit: "Musica",
    icon: "Music",
    estimatedCost: 1800,
    actualCost: 1600,
    percentage: 7,
    color: "#4CAF50",
    subcategories: [
      { name: "DJ/Band", cost: 1200 },
      { name: "Audio/luci", cost: 400 }
    ]
  },
  {
    id: 6,
    name: "Fiori e Decorazioni",
    nameit: "Decorazioni",
    icon: "Flower",
    estimatedCost: 1200,
    actualCost: 1100,
    percentage: 5,
    color: "#FF5722",
    subcategories: [
      { name: "Bouquet", cost: 300 },
      { name: "Centrotavola", cost: 500 },
      { name: "Decorazioni chiesa", cost: 300 }
    ]
  },
  {
    id: 7,
    name: "Trasporto",
    nameit: "Trasporto",
    icon: "Car",
    estimatedCost: 600,
    actualCost: 550,
    percentage: 2,
    color: "#607D8B",
    subcategories: [
      { name: "Auto sposi", cost: 400 },
      { name: "Trasferimenti invitati", cost: 150 }
    ]
  },
  {
    id: 8,
    name: "Varie",
    nameit: "Altro",
    icon: "MoreHorizontal",
    estimatedCost: 240,
    actualCost: 200,
    percentage: 1,
    color: "#795548",
    subcategories: [
      { name: "Partecipazioni", cost: 100 },
      { name: "Bomboniere", cost: 100 }
    ]
  }
];

export const mockVendors = [
  {
    id: 1,
    categoryId: 1,
    name: "Villa San Martino",
    cost: 8000,
    paid: 3000,
    remaining: 5000,
    dueDate: "2024-06-15",
    status: "partial",
    notes: "Pagato acconto del 30%",
    contact: "+39 333 123 4567"
  },
  {
    id: 2,
    categoryId: 2,
    name: "Catering Il Convivio",
    cost: 5800,
    paid: 0,
    remaining: 5800,
    dueDate: "2024-05-20",
    status: "pending",
    notes: "Confermare menu definitivo",
    contact: "+39 334 987 6543"
  },
  {
    id: 3,
    categoryId: 3,
    name: "Studio Fotografico Luce",
    cost: 3200,
    paid: 800,
    remaining: 2400,
    dueDate: "2024-07-01",
    status: "partial",
    notes: "Pagato 25% di acconto",
    contact: "+39 335 456 7890"
  }
];

export const mockStats = {
  totalBudget: 24000,
  totalSpent: 3800,
  totalEstimated: 22640,
  remainingBudget: 1360,
  percentageSpent: 16,
  vendorsPaid: 3,
  vendorsTotal: 12,
  daysToWedding: 120
};

export const mockRecentActivities = [
  {
    id: 1,
    type: "payment",
    description: "Pagamento acconto Villa San Martino",
    amount: 3000,
    date: "2024-03-15"
  },
  {
    id: 2,
    type: "expense",
    description: "Aggiunta spese trucco e parrucchiere",
    amount: 300,
    date: "2024-03-12"
  },
  {
    id: 3,
    type: "vendor",
    description: "Nuovo fornitore aggiunto: Fotografo",
    amount: 3200,
    date: "2024-03-10"
  }
];

export const mockUpcomingPayments = [
  {
    id: 1,
    vendor: "Catering Il Convivio",
    amount: 5800,
    dueDate: "2024-05-20",
    category: "Catering"
  },
  {
    id: 2,
    vendor: "Villa San Martino (saldo)",
    amount: 5000,
    dueDate: "2024-06-15",
    category: "Location"
  },
  {
    id: 3,
    vendor: "Studio Fotografico Luce",
    amount: 2400,
    dueDate: "2024-07-01",
    category: "Fotografia"
  }
];